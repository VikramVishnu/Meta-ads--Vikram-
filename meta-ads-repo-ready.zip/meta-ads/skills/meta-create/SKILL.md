---
name: meta-create
description: "Campaign concept and copy brief generator for paid advertising. Reads brand-profile.json and optional audit results to produce structured campaign concepts, messaging pillars, and copy briefs. Outputs campaign-brief.md to the current directory. Run after /meta-ads dna and before /meta-ads generate. Triggers on: create campaign, campaign brief, ad concepts, write ad copy, campaign strategy, ad messaging, creative brief, generate concepts."
user-invokable: true
tested_date: 2026-05-17
tested_with: claude-code v2.x
---

# Ads Create: Campaign Concept & Copy Brief Generator

Generates structured campaign concepts and platform-specific copy from your brand
profile and optional audit data. Outputs `campaign-brief.md` for use by `/meta-ads generate`.

Operates under the **10-Principle Thinking Framework** (see
`meta-ads/references/thinking-framework.md`). LISTEN to the brand voice before
typing; FEEL the emotional resonance of every headline and CTA; CREATE
the deliverable — do not hedge concepts so heavily that the next person
has to do the work. Spec compliance without emotional pull is a fail.

## Quick Reference

| Command | What it does |
|---------|-------------|
| `/meta-ads create` | Full campaign brief → `campaign-brief.md` |
| `/meta-ads create --placements reels feed` | Brief for specific Meta placements only |
| `/meta-ads create --objective leads` | Brief optimized for lead generation |

## Process

### Step 1: Check for Brand Profile

Look for `brand-profile.json` in the current directory.

- **Found**: Load and proceed.
- **Not found**: Ask the user:
  > "I don't see a brand-profile.json in this directory. Would you like to:
  > 1. Run `/meta-ads dna <url>` first to extract brand DNA automatically
  > 2. Describe your brand manually (I'll create a basic profile from your description)"

If the user chooses manual, collect:
- Brand name and website
- Primary color (or "unsure")
- 3 words that describe the brand voice
- Target audience (age, role, key pain point)
- Main product/service offering

### Step 2: Check for Audit Results

Look for `ADS-AUDIT-REPORT.md` or any `*-audit-results.md` in the current directory.

- **Found**: Read them. Note the top 3 weaknesses (creative fatigue, tracking gaps, wasted spend) to address in concepts.
- **Not found**: Continue without. Note in the brief: "No audit data found; concepts are generalized. Run `/meta-ads audit` for weakness-targeted concepts."

### Step 3: Collect Campaign Parameters

If `--placements` or `--objective` flags were provided in the command, use those values
and skip the corresponding questions below.

Ask (combine into one message; omit any already provided via flags):
1. **Placements / objective focus**: Which Meta surfaces? (Facebook Feed · Instagram Feed · Reels · Stories · Advantage+ Shopping · All placements)
2. **Objective**: Sales/Revenue · Leads/Demos · App Installs · Brand Awareness · Retargeting
3. **Offer or brief**: Any specific offer, promotion, or message to highlight? (optional)
4. **Number of concepts**: How many campaign concepts? (default: 3)

### Step 4: Select Copy Framework

Read `meta-ads/references/copy-frameworks.md` and recommend a framework based on
campaign goal + platform + audience temperature:

| Framework | Best For |
|-----------|----------|
| AIDA (Attention, Interest, Desire, Action) | Cold audiences, awareness campaigns |
| PAS (Problem, Agitate, Solve) | Pain-point products, problem-aware audiences |
| BAB (Before, After, Bridge) | Transformation offers, coaching, fitness |
| 4P (Promise, Picture, Proof, Push) | Direct response, high-intent audiences |
| FAB (Features, Advantages, Benefits) | Product-focused, comparison shoppers |
| Star-Story-Solution | Brand storytelling, warm audiences |

Include the selected framework name in campaign-brief.md for the copy-writer agent.

### Step 5: Spawn Creative Agents in Sequence

Agents must run **sequentially**; `copy-writer` reads the file that `creative-strategist`
writes, so running them in parallel creates a race condition on `campaign-brief.md`.

**Step 5a; Spawn `creative-strategist`** (Task tool):
This agent creates `campaign-brief.md` and writes the strategic sections:
`## Brand DNA Summary`, `## Campaign Concepts`, `## Image Generation Briefs`, `## Next Steps`.

Additional instructions for `creative-strategist`:
- For e-commerce businesses, also read `skills/meta-plan/assets/ecommerce-creative.md`
  and select the appropriate creative playbook (Product Launch, Sale/Promotion,
  Seasonal, Retargeting, Brand Awareness)
- Include banana domain mode recommendations in each Image Generation Brief
  (Product, Editorial, Cinema, UI/Web, or Portrait)

Wait for `creative-strategist` to **fully complete** before continuing.

**Step 5b; Spawn `copy-writer`** (Task tool):
After `creative-strategist` completes, spawn `copy-writer`. It reads the existing
`campaign-brief.md` and appends the `## Copy Deck` section with platform-specific
headlines, primary text, and CTAs.

Additional instructions for `copy-writer`:
- Read `meta-ads/references/copy-frameworks.md` and apply the selected framework
  structure to all ad copy
- Generate 2 framework variants per platform: primary (recommended framework)
  + secondary (alternative for A/B testing)

Wait for `copy-writer` to complete before proceeding to Step 6.

### Step 6: Review and Present

After both agents complete, confirm `campaign-brief.md` exists and is complete.

Present a summary to the user:
```
✓ campaign-brief.md generated

Summary:
  Concepts: [N] campaign concepts created
  Placements / objective: [list]
  Copy deck: Headlines, primary text, and CTAs for each concept × platform
  Image briefs: [N] image generation briefs ready

Next steps:
  1. Review campaign-brief.md and adjust any messaging
  2. Run `/meta-ads generate` to produce AI images from the briefs
  3. Upload copy and assets to your ad platforms
```

## campaign-brief.md Format Specification

The following section headings are a **parsing contract**; agents downstream depend on these exact heading names.

```markdown
# Campaign Brief: [brand_name]
**Generated:** [date]
**Website:** [website_url]
**Platforms:** [comma-separated list]
**Objective:** [objective]
**Concepts:** [N]

## Brand DNA Summary
[3-sentence synthesis of brand-profile.json: voice, visual identity, target audience]

## Audit Context
[If audit data found: top 3 weaknesses being addressed]
[If no audit data: "No audit data; run /meta-ads audit for weakness-targeted concepts"]

## Campaign Concepts

### Concept 1: [Name]
**Hypothesis:** [why this will work; 1 sentence]
**Primary Message:** [core message; 1 sentence]
**Tone:** [voice reading from brand-profile.json]
**Visual Direction:** [2-3 sentences describing imagery]
**Target Platforms:** [platforms and rationale]
**CTA:** [call to action text]
**Addresses:** [audit finding or "general brand awareness"]

### Concept 2: [Name]
[same structure]

[repeat for all concepts]

## Copy Deck
[appended by copy-writer agent; headlines, primary text, CTAs per concept per platform]

## Image Generation Briefs

### Brief 1: [Concept Name]: [Platform]
**Prompt:** [exact generation prompt]
**Dimensions:** [WxH]
**Safe zone notes:** [constraint or "None"]

### Brief 2: [Concept Name]: [Platform]
**Prompt:** [exact generation prompt]
**Dimensions:** [WxH]
**Safe zone notes:** [constraint or "None"]

[one brief per concept × platform combination]

## Next Steps
1. Review all concepts and select which to move forward with
2. Run `/meta-ads generate` to produce images from the briefs above
3. Adjust CTAs and offers in the copy deck for your specific promotion
4. Upload final assets to your ad platform managers
```

## Quality Gates

- **Minimum 3 concepts** (unless user requests fewer)
- **Distinct angles**: no two concepts share the same primary message angle
- **Platform fit**: concepts targeting Reels/Stories must acknowledge vertical-only format and sound-on context
- **Offer anchoring**: if the user provided a specific offer, at least 1 concept must lead with it
- **Image briefs**: every concept must have at least one image brief per requested platform

## Meta Andromeda Optimization

For Meta campaigns: recommend diverse creative concepts (different motivators, visual styles, messaging angles) to maximize Andromeda retrieval. Similarity Score >60% between ads triggers clustering and suppression.

## Meta Character Limits

Verify Meta character limits are current: primary text ~125 chars visible before the "…more" fold, headline ~40 chars, description shown on select placements. Meta reduced headline display length on mobile in 2025 — front-load the hook.
