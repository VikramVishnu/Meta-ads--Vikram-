#Requires -Version 5.1
<#
.SYNOPSIS
    Meta Ads Uninstaller for Windows (multi-host).
.DESCRIPTION
    Removes every ads-* sub-skill directory plus the orchestrator and bundled
    agents from the chosen host's install root. Uses glob discovery so new
    sub-skills don't require uninstaller updates.
.PARAMETER Target
    Which host CLI to uninstall from. Default: claude.
#>

param(
    [ValidateSet('claude','codex','cursor','windsurf','gemini','goose')]
    [string]$Target = 'claude'
)

$ErrorActionPreference = "Stop"

function Resolve-TargetPaths {
    param([string]$T)
    switch ($T) {
        'claude'   { return @{ SkillBase = Join-Path $env:USERPROFILE ".claude\skills";                                AgentDir = Join-Path $env:USERPROFILE ".claude\agents" } }
        'codex'    { return @{ SkillBase = Join-Path $env:USERPROFILE ".codex\skills";                                 AgentDir = Join-Path $env:USERPROFILE ".codex\agents" } }
        'cursor'   { return @{ SkillBase = Join-Path $env:USERPROFILE ".cursor\extensions\meta-ads\skills";          AgentDir = Join-Path $env:USERPROFILE ".cursor\extensions\meta-ads\agents" } }
        'windsurf' { return @{ SkillBase = Join-Path $env:USERPROFILE ".windsurf\skills";                              AgentDir = Join-Path $env:USERPROFILE ".windsurf\agents" } }
        'gemini'   { return @{ SkillBase = Join-Path $env:USERPROFILE ".gemini\extensions\meta-ads\skills";          AgentDir = Join-Path $env:USERPROFILE ".gemini\extensions\meta-ads\agents" } }
        'goose'    { return @{ SkillBase = Join-Path $env:USERPROFILE ".config\goose\skills";                          AgentDir = Join-Path $env:USERPROFILE ".config\goose\agents" } }
        default    { throw "Unknown target: $T" }
    }
}

function Main {
    $paths = Resolve-TargetPaths -T $Target
    $SkillBase = $paths.SkillBase
    $AgentDir = $paths.AgentDir

    Write-Host "Uninstalling Meta Ads from $SkillBase and $AgentDir..."

    # Remove orchestrator
    $MainSkill = Join-Path $SkillBase "meta-ads"
    if (Test-Path $MainSkill) {
        Remove-Item -Path $MainSkill -Recurse -Force
    }

    # Remove all ads-* sub-skills via glob
    if (Test-Path $SkillBase) {
        Get-ChildItem -Path $SkillBase -Directory -Filter "meta-*" -ErrorAction SilentlyContinue | ForEach-Object {
            Remove-Item -Path $_.FullName -Recurse -Force
        }
    }

    # Remove bundled audit + creative agents.
    # NOTE: Keep this list in sync with the contents of `agents/` in the repo.
    # install.ps1 uses `Copy-Item agents\*.md` so any new agent file added
    # there must also be appended below. Pre-v1.7.1 the list contained
    # non-existent entries (audit-amazon, audit-attribution, audit-server-side)
    # and missed the actual shipped agents.
    $Agents = @(
        "meta-audit-core", "meta-audit-creative", "meta-audit-tracking",
        "meta-audit-budget", "meta-audit-compliance",
        "meta-copy-writer", "meta-creative-strategist", "meta-format-adapter", "meta-visual-designer"
    )
    foreach ($agent in $Agents) {
        $AgentPath = Join-Path $AgentDir "$agent.md"
        if (Test-Path $AgentPath) {
            Remove-Item -Path $AgentPath -Force
        }
    }

    Write-Host "[OK] Meta Ads uninstalled." -ForegroundColor Green
}

Main
