#Requires -Version 5.1
<#
.SYNOPSIS
    Meta Ads Installer for Windows (multi-host).
.DESCRIPTION
    Installs the Meta Ads skill, sub-skills, agents, and reference files
    for Claude Code (default) or any of the supported experimental host CLIs.

    Targets:
      claude     Claude Code (verified)
      codex      OpenAI Codex CLI (experimental)
      cursor     Cursor IDE (experimental)
      windsurf   Windsurf IDE (experimental)
      gemini     Gemini CLI (experimental)
      goose      Goose CLI (experimental)
.PARAMETER Target
    Which host CLI to install for. Default: claude.
.PARAMETER SkillDir
    Override the target's default skill install root.
.PARAMETER AgentDir
    Override the target's default agent install root.
.EXAMPLE
    .\install.ps1
.EXAMPLE
    .\install.ps1 -Target codex
.EXAMPLE
    .\install.ps1 -SkillDir C:\Custom\Skills
#>

param(
    [ValidateSet('claude','codex','cursor','windsurf','gemini','goose')]
    [string]$Target = 'claude',
    [string]$SkillDir = '',
    [string]$AgentDir = ''
)

$ErrorActionPreference = "Stop"

function Resolve-TargetPaths {
    param([string]$T)
    switch ($T) {
        'claude' {
            return @{
                SkillBase = Join-Path $env:USERPROFILE ".claude\skills"
                AgentDir  = Join-Path $env:USERPROFILE ".claude\agents"
                AllowPip  = $true
                Label     = "Claude Code"
            }
        }
        'codex' {
            return @{
                SkillBase = Join-Path $env:USERPROFILE ".codex\skills"
                AgentDir  = Join-Path $env:USERPROFILE ".codex\agents"
                AllowPip  = $true
                Label     = "OpenAI Codex CLI"
            }
        }
        'cursor' {
            return @{
                SkillBase = Join-Path $env:USERPROFILE ".cursor\extensions\meta-ads\skills"
                AgentDir  = Join-Path $env:USERPROFILE ".cursor\extensions\meta-ads\agents"
                AllowPip  = $false
                Label     = "Cursor IDE"
            }
        }
        'windsurf' {
            return @{
                SkillBase = Join-Path $env:USERPROFILE ".windsurf\skills"
                AgentDir  = Join-Path $env:USERPROFILE ".windsurf\agents"
                AllowPip  = $false
                Label     = "Windsurf IDE"
            }
        }
        'gemini' {
            return @{
                SkillBase = Join-Path $env:USERPROFILE ".gemini\extensions\meta-ads\skills"
                AgentDir  = Join-Path $env:USERPROFILE ".gemini\extensions\meta-ads\agents"
                AllowPip  = $false
                Label     = "Gemini CLI"
            }
        }
        'goose' {
            return @{
                SkillBase = Join-Path $env:USERPROFILE ".config\goose\skills"
                AgentDir  = Join-Path $env:USERPROFILE ".config\goose\agents"
                AllowPip  = $false
                Label     = "Goose CLI"
            }
        }
        default {
            throw "Unknown target: $T"
        }
    }
}

function Test-InstallPath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    if ($Path -match '[\;\&\|\$\(\)\<\>\`]') { return $false }
    if ($Path -match '\.\.') { return $false }
    if ($Path -match '^[-]') { return $false }
    if ($Path -match '^(\\\\|//)') { return $false }   # UNC paths
    return $true
}

function Main {
    $paths = Resolve-TargetPaths -T $Target
    $SkillBase = $paths.SkillBase
    $AgentDirResolved = $paths.AgentDir
    $AllowPip = $paths.AllowPip
    $HostLabel = $paths.Label

    if ($SkillDir) {
        if (-not (Test-InstallPath -Path $SkillDir)) {
            Write-Host "X Invalid -SkillDir: contains forbidden characters or traversal" -ForegroundColor Red
            exit 1
        }
        $SkillBase = $SkillDir
    }
    if ($AgentDir) {
        if (-not (Test-InstallPath -Path $AgentDir)) {
            Write-Host "X Invalid -AgentDir: contains forbidden characters or traversal" -ForegroundColor Red
            exit 1
        }
        $AgentDirResolved = $AgentDir
    }

    $SkillDirResolved = Join-Path $SkillBase "meta-ads"
    $RepoUrl = "https://github.com/AI-Marketing-Hub/meta-ads"

    Write-Host "=================================="
    Write-Host "   Meta Ads - Installer"
    Write-Host "   Target: $HostLabel"
    Write-Host "=================================="
    Write-Host ""

    # Check prerequisites
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        Write-Host "X Git is required but not installed." -ForegroundColor Red
        exit 1
    }
    Write-Host "OK Git detected" -ForegroundColor Green

    # Create directories
    New-Item -ItemType Directory -Path (Join-Path $SkillDirResolved "references") -Force | Out-Null
    New-Item -ItemType Directory -Path $AgentDirResolved -Force | Out-Null

    # Clone to temp directory
    $TempDir = Join-Path $env:TEMP "meta-ads-install-$(Get-Random)"
    Write-Host "Downloading Meta Ads..."

    try {
        # Temporarily allow stderr (git writes progress to stderr — treated as error in PS 5.1)
        $ErrorActionPreference = "Continue"
        git clone --depth 1 $RepoUrl "$TempDir\meta-ads" 2>&1 | Out-Null
        $ErrorActionPreference = "Stop"
        if ($LASTEXITCODE -ne 0) { throw "Git clone failed" }

        # Copy main skill + references
        Write-Host "Installing skill files..."
        Copy-Item "$TempDir\meta-ads\meta-ads\SKILL.md" -Destination "$SkillDirResolved\SKILL.md" -Force
        Copy-Item "$TempDir\meta-ads\meta-ads\references\*.md" -Destination "$SkillDirResolved\references\" -Force

        # Copy sub-skills
        Write-Host "Installing sub-skills..."
        Get-ChildItem "$TempDir\meta-ads\skills" -Directory | ForEach-Object {
            $TargetDir = Join-Path $SkillBase $_.Name
            New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
            Copy-Item (Join-Path $_.FullName "SKILL.md") -Destination "$TargetDir\SKILL.md" -Force

            # Copy assets (industry templates) if they exist
            $AssetsDir = Join-Path $_.FullName "assets"
            if (Test-Path $AssetsDir) {
                $TargetAssets = Join-Path $TargetDir "assets"
                New-Item -ItemType Directory -Path $TargetAssets -Force | Out-Null
                Copy-Item "$AssetsDir\*.md" -Destination "$TargetAssets\" -Force
            }
        }

        # Copy agents
        Write-Host "Installing subagents..."
        Copy-Item "$TempDir\meta-ads\agents\*.md" -Destination "$AgentDirResolved\" -Force

        # Copy scripts (optional Python tools)
        $ScriptsSource = "$TempDir\meta-ads\scripts"
        if (Test-Path $ScriptsSource) {
            Write-Host "Installing Python scripts..."
            $ScriptsDir = Join-Path $SkillDirResolved "scripts"
            New-Item -ItemType Directory -Path $ScriptsDir -Force | Out-Null
            Copy-Item "$ScriptsSource\*.py" -Destination "$ScriptsDir\" -Force
            Copy-Item "$TempDir\meta-ads\requirements.txt" -Destination "$SkillDirResolved\requirements.txt" -Force
        }

        Write-Host ""
        if ($AllowPip) {
            Write-Host "Installing Python dependencies..."
            $ErrorActionPreference = "Continue"
            pip install -q -r "$SkillDirResolved\requirements.txt" 2>$null
            if ($LASTEXITCODE -eq 0) {
                Write-Host "  OK Python dependencies installed" -ForegroundColor Green
            } else {
                Write-Host "  Warning: pip install failed. Run manually: pip install -r $SkillDirResolved\requirements.txt" -ForegroundColor Yellow
            }
            $ErrorActionPreference = "Stop"
        } else {
            Write-Host "i  Skipping Python dependencies - $HostLabel host runtime may not execute Python skills directly." -ForegroundColor Yellow
            Write-Host "   If you need PDF reports / landing-page analysis / screenshots, install manually:"
            Write-Host "     pip install -r $SkillDirResolved\requirements.txt"
        }

        # Check for banana-claude (image generation provider)
        Write-Host ""
        $BananaPath = Join-Path $SkillBase "banana\SKILL.md"
        if (Test-Path $BananaPath) {
            Write-Host "  OK banana-claude detected (image generation ready)" -ForegroundColor Green
        } else {
            Write-Host "  Warning: banana-claude not installed. Image generation requires it." -ForegroundColor Yellow
            Write-Host "    Install: https://github.com/AgriciDaniel/banana-claude"
            Write-Host "    Then run: /banana setup (to configure API key)"
        }

        Write-Host ""
        Write-Host "Meta Ads installed successfully for $HostLabel!" -ForegroundColor Green
        Write-Host ""
        Write-Host "  Installed to:"
        Write-Host "    Skills: $SkillBase"
        Write-Host "    Agents: $AgentDirResolved"
        Write-Host ""
        Write-Host "  Bundled:"
        Write-Host "    - 1 main skill (meta-ads orchestrator)"
        Write-Host "    - 15 sub-skills (audit + functional + creative)"
        Write-Host "    - 9 agents (5 audit + 4 creative)"
        Write-Host "    - 15 reference files"
        Write-Host "    - 12 industry templates"
        Write-Host ""
        Write-Host "Usage:"
        Write-Host "  1. Start your host CLI"
        Write-Host "  2. Run commands:       /meta-ads audit"
        Write-Host "                         /meta-ads plan saas"
        Write-Host "                         /meta-ads analyze"
        Write-Host ""
        Write-Host "To uninstall: .\uninstall.ps1 -Target $Target"
    }
    finally {
        # Cleanup temp directory
        if (Test-Path $TempDir) {
            Remove-Item -Path $TempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

Main
